# CHEKK — Android checklist app

CHEKK is a simple, offline Android checklist app built around the two images supplied for this project.

## Included features

- Full-screen Luffy wallpaper, with all app text drawn directly over the image (no section cards or opaque content panels).
- The supplied Straw Hat image is used as the app launcher icon and the small in-app mark.
- Home screen starts with **No section available**.
- Top-left menu: Add section, Edit sections, Delete sections, Settings.
- Up to **50 sections**.
- Open a section to see its tasks; use the back arrow or Android Back to return home.
- Add up to **100 tasks per section**, one task at a time.
- Tap a task to animate a strike-through; tap again to remove it.
- Long-press a section or task to edit or delete it.
- Section names, tasks, and checked/unchecked states are saved locally on the device.
- No sign-in, no internet permission, and Android backup is disabled.

## Data storage note

CHEKK saves data in the app's private local storage. It survives closing the app and restarting the phone. Because this version has no account or cloud backup, **uninstalling CHEKK or clearing its app data deletes the saved checklists**. The app does not sync data to another device.

## Build an installable APK

This workspace did not have the Android SDK or a preinstalled Gradle distribution, and network access to Google's Android SDK download host was unavailable. Therefore an APK could not be compiled or device-tested in this environment. The complete Android Studio project is included here.

On a computer with Android Studio:

1. Install Android Studio and its Android SDK Platform 35 / Build Tools.
2. Open this `CHEKK` folder as an existing Android Studio project.
3. Allow Gradle to sync (the project uses Android Gradle Plugin 8.7.3 and Gradle 8.9).
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android device and install it. Android may ask you to allow installs from that file manager/browser.

Or, from a terminal in this folder, run:

- macOS/Linux: `./gradlew assembleDebug`
- Windows: `gradlew.bat assembleDebug`

The included bootstrap scripts download Gradle 8.9 on first run. Android Gradle Plugin and SDK components also need internet access during the first build.

## Project details

- Application ID: `com.chekk.app`
- Minimum Android version: Android 6.0 (API 23)
- Compile / target SDK: 35
- Language: Java
- No third-party runtime libraries

## Supplied artwork

`app/src/main/res/drawable-nodpi/wallpaper.jpg` and `chekk_logo.png` are the image files provided in the chat. The launcher icon is generated from the supplied square logo image without cropping.
