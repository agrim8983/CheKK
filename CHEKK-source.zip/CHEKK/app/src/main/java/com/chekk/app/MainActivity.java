package com.chekk.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.UUID;

/**
 * CHEKK - a wallpaper-first, offline checklist app.
 * All checklist data is stored locally in SharedPreferences.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "chekk_local_data";
    private static final String DATA_KEY = "sections_json";
    private static final int MAX_SECTIONS = 50;
    private static final int MAX_TASKS_PER_SECTION = 100;

    private final ArrayList<Section> sections = new ArrayList<>();
    private FrameLayout root;
    private LinearLayout content;
    private String currentSectionId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();
        loadData();
        buildRoot();
        renderHome();
    }

    private void configureSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void buildRoot() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView wallpaper = new ImageView(this);
        wallpaper.setImageResource(R.drawable.wallpaper);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setContentDescription("CHEKK wallpaper");
        root.addView(wallpaper, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipToPadding(false);
        content.setPadding(dp(14), getStatusBarHeight() + dp(7), dp(14), getNavigationBarHeight() + dp(10));
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
    }

    private void renderHome() {
        currentSectionId = null;
        content.removeAllViews();
        content.addView(makeHomeToolbar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(5), dp(20), dp(5), dp(24));

        if (sections.isEmpty()) {
            TextView empty = styledText("No section available", 22, Typeface.NORMAL);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            for (Section section : sections) {
                list.addView(makeSectionRow(section));
            }
        }
        scroll.addView(list, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        content.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private View makeHomeToolbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        TextView menu = iconText("☰", 29);
        menu.setContentDescription("Open menu");
        menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v -> showHomeMenu(menu));
        bar.addView(menu, new LinearLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.MATCH_PARENT));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.chekk_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("CHEKK app logo");
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(38), dp(38));
        logoParams.leftMargin = dp(5);
        bar.addView(logo, logoParams);

        TextView title = styledText("CHEKK", 27, Typeface.BOLD);
        title.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        titleParams.leftMargin = dp(9);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, titleParams);
        return bar;
    }

    private View makeSectionRow(Section section) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(9), dp(13), dp(9), dp(13));
        row.setMinimumHeight(dp(58));
        row.setClickable(true);
        row.setFocusable(true);

        TextView name = styledText(section.name, 23, Typeface.BOLD);
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView arrow = styledText("›", 34, Typeface.NORMAL);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(34), ViewGroup.LayoutParams.MATCH_PARENT));

        row.setOnClickListener(v -> renderSection(section.id));
        row.setOnLongClickListener(v -> {
            showSectionActions(section);
            return true;
        });
        return row;
    }

    private void renderSection(String sectionId) {
        Section section = findSection(sectionId);
        if (section == null) {
            renderHome();
            return;
        }
        currentSectionId = sectionId;
        content.removeAllViews();
        content.addView(makeSectionToolbar(section), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(7), dp(18), dp(7), dp(28));

        if (section.tasks.isEmpty()) {
            TextView empty = styledText("No tasks yet", 20, Typeface.NORMAL);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            for (Task task : section.tasks) {
                list.addView(makeTaskRow(section, task));
            }
        }
        scroll.addView(list, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        content.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private View makeSectionToolbar(Section section) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = iconText("‹", 38);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back to home");
        back.setOnClickListener(v -> renderHome());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = styledText(section.name, 21, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        TextView add = iconText("＋", 31);
        add.setGravity(Gravity.CENTER);
        add.setContentDescription("Add task");
        add.setOnClickListener(v -> showAddTaskDialog(section));
        bar.addView(add, new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT));

        TextView more = iconText("⋮", 28);
        more.setGravity(Gravity.CENTER);
        more.setContentDescription("Section options");
        more.setOnClickListener(v -> showSectionMenu(more, section));
        bar.addView(more, new LinearLayout.LayoutParams(dp(34), ViewGroup.LayoutParams.MATCH_PARENT));
        return bar;
    }

    private View makeTaskRow(Section section, Task task) {
        StrikeTextView row = new StrikeTextView(this);
        row.setText(task.name);
        row.setTextSize(22);
        row.setTextColor(Color.WHITE);
        row.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        row.setPadding(dp(11), dp(14), dp(12), dp(14));
        row.setMinHeight(dp(54));
        row.setShadowLayer(dp(5), dp(1), dp(2), 0xDD000000);
        row.setStrikeProgress(task.done ? 1f : 0f);
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(v -> {
            task.done = !task.done;
            row.animateStrike(task.done);
            saveData();
        });
        row.setOnLongClickListener(v -> {
            showTaskActions(section, task);
            return true;
        });
        return row;
    }

    private void showHomeMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(0, 1, 0, "Add section");
        popup.getMenu().add(0, 2, 1, "Edit sections");
        popup.getMenu().add(0, 3, 2, "Delete sections");
        popup.getMenu().add(0, 4, 3, "Settings");
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: showAddSectionDialog(); return true;
                case 2: chooseSectionForEdit(); return true;
                case 3: chooseSectionForDelete(); return true;
                case 4: showSettings(); return true;
                default: return false;
            }
        });
        popup.show();
    }

    private void showSectionMenu(View anchor, Section section) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(0, 1, 0, "Edit section");
        popup.getMenu().add(0, 2, 1, "Delete section");
        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == 1) {
                showEditSectionDialog(section);
                return true;
            } else if (item.getItemId() == 2) {
                confirmDeleteSection(section);
                return true;
            }
            return false;
        });
        popup.show();
    }

    private void showAddSectionDialog() {
        if (sections.size() >= MAX_SECTIONS) {
            toast("You can add up to 50 sections.");
            return;
        }
        EditText input = makeDialogInput("Section name");
        new AlertDialog.Builder(this)
                .setTitle("Add section")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = clean(input.getText().toString());
                    if (name.isEmpty()) {
                        toast("Enter a section name.");
                        return;
                    }
                    if (findSectionByName(name) != null) {
                        toast("A section with that name already exists.");
                        return;
                    }
                    Section section = new Section(UUID.randomUUID().toString(), name);
                    sections.add(section);
                    saveData();
                    renderSection(section.id);
                })
                .show();
    }

    private void showAddTaskDialog(Section section) {
        if (section.tasks.size() >= MAX_TASKS_PER_SECTION) {
            toast("You can add up to 100 tasks in one section.");
            return;
        }
        EditText input = makeDialogInput("Task name");
        new AlertDialog.Builder(this)
                .setTitle("Add task")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = clean(input.getText().toString());
                    if (name.isEmpty()) {
                        toast("Enter a task name.");
                        return;
                    }
                    Task task = new Task(UUID.randomUUID().toString(), name, false);
                    section.tasks.add(task);
                    saveData();
                    renderSection(section.id);
                })
                .show();
    }

    private void chooseSectionForEdit() {
        if (sections.isEmpty()) { toast("No sections to edit."); return; }
        String[] names = new String[sections.size()];
        for (int i = 0; i < sections.size(); i++) names[i] = sections.get(i).name;
        new AlertDialog.Builder(this).setTitle("Choose a section")
                .setItems(names, (d, which) -> showEditSectionDialog(sections.get(which)))
                .setNegativeButton("Cancel", null).show();
    }

    private void chooseSectionForDelete() {
        if (sections.isEmpty()) { toast("No sections to delete."); return; }
        String[] names = new String[sections.size()];
        for (int i = 0; i < sections.size(); i++) names[i] = sections.get(i).name;
        new AlertDialog.Builder(this).setTitle("Choose a section to delete")
                .setItems(names, (d, which) -> confirmDeleteSection(sections.get(which)))
                .setNegativeButton("Cancel", null).show();
    }

    private void showSectionActions(Section section) {
        new AlertDialog.Builder(this).setTitle(section.name)
                .setItems(new String[]{"Edit section", "Delete section"}, (dialog, which) -> {
                    if (which == 0) showEditSectionDialog(section);
                    else confirmDeleteSection(section);
                }).show();
    }

    private void showEditSectionDialog(Section section) {
        EditText input = makeDialogInput("Section name");
        input.setText(section.name);
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(this).setTitle("Edit section")
                .setView(input).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, which) -> {
                    String name = clean(input.getText().toString());
                    if (name.isEmpty()) { toast("Section name cannot be empty."); return; }
                    Section duplicate = findSectionByName(name);
                    if (duplicate != null && !duplicate.id.equals(section.id)) {
                        toast("A section with that name already exists.");
                        return;
                    }
                    section.name = name;
                    saveData();
                    if (currentSectionId != null && currentSectionId.equals(section.id)) renderSection(section.id);
                    else renderHome();
                }).show();
    }

    private void confirmDeleteSection(Section section) {
        new AlertDialog.Builder(this).setTitle("Delete section?")
                .setMessage("Delete \"" + section.name + "\" and all its tasks?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, which) -> {
                    sections.remove(section);
                    saveData();
                    renderHome();
                }).show();
    }

    private void showTaskActions(Section section, Task task) {
        new AlertDialog.Builder(this).setTitle(task.name)
                .setItems(new String[]{"Edit task", "Delete task"}, (dialog, which) -> {
                    if (which == 0) showEditTaskDialog(section, task);
                    else confirmDeleteTask(section, task);
                }).show();
    }

    private void showEditTaskDialog(Section section, Task task) {
        EditText input = makeDialogInput("Task name");
        input.setText(task.name);
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(this).setTitle("Edit task")
                .setView(input).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, which) -> {
                    String name = clean(input.getText().toString());
                    if (name.isEmpty()) { toast("Task name cannot be empty."); return; }
                    task.name = name;
                    saveData();
                    renderSection(section.id);
                }).show();
    }

    private void confirmDeleteTask(Section section, Task task) {
        new AlertDialog.Builder(this).setTitle("Delete task?")
                .setMessage("Delete \"" + task.name + "\"?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, which) -> {
                    section.tasks.remove(task);
                    saveData();
                    renderSection(section.id);
                }).show();
    }

    private void showSettings() {
        new AlertDialog.Builder(this).setTitle("CHEKK settings")
                .setMessage("CHEKK stores your sections and tasks only on this device. No account or internet connection is used. Your data is removed when you uninstall the app.\n\nLimits: 50 sections and 100 tasks per section.\n\nTip: Long-press a section or task to edit or delete it.")
                .setPositiveButton("Done", null).show();
    }

    private EditText makeDialogInput(String hint) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(16);
        input.setHint(hint);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        int pad = dp(18);
        input.setPadding(pad, dp(12), pad, dp(12));
        return input;
    }

    private TextView styledText(String value, int sizeSp, int style) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(sizeSp);
        text.setTextColor(Color.WHITE);
        text.setTypeface(Typeface.create("sans-serif", style));
        text.setShadowLayer(dp(5), dp(1), dp(2), 0xE6000000);
        return text;
    }

    private TextView iconText(String value, int sizeSp) {
        TextView text = styledText(value, sizeSp, Typeface.NORMAL);
        text.setIncludeFontPadding(true);
        text.setClickable(true);
        text.setFocusable(true);
        return text;
    }

    private void loadData() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = prefs.getString(DATA_KEY, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            sections.clear();
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i);
                Section section = new Section(object.optString("id", UUID.randomUUID().toString()),
                        object.optString("name", "Untitled section"));
                JSONArray tasks = object.optJSONArray("tasks");
                if (tasks != null) {
                    for (int j = 0; j < tasks.length(); j++) {
                        JSONObject taskObject = tasks.getJSONObject(j);
                        section.tasks.add(new Task(
                                taskObject.optString("id", UUID.randomUUID().toString()),
                                taskObject.optString("name", "Untitled task"),
                                taskObject.optBoolean("done", false)));
                    }
                }
                sections.add(section);
            }
        } catch (JSONException e) {
            sections.clear();
            Toast.makeText(this, "Saved data could not be read. A fresh list was opened.", Toast.LENGTH_LONG).show();
        }
    }

    private void saveData() {
        JSONArray array = new JSONArray();
        try {
            for (Section section : sections) {
                JSONObject object = new JSONObject();
                object.put("id", section.id);
                object.put("name", section.name);
                JSONArray tasks = new JSONArray();
                for (Task task : section.tasks) {
                    JSONObject taskObject = new JSONObject();
                    taskObject.put("id", task.id);
                    taskObject.put("name", task.name);
                    taskObject.put("done", task.done);
                    tasks.put(taskObject);
                }
                object.put("tasks", tasks);
                array.put(object);
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(DATA_KEY, array.toString()).apply();
        } catch (JSONException ignored) {
            toast("Could not save your changes.");
        }
    }

    private Section findSection(String id) {
        for (Section section : sections) if (section.id.equals(id)) return section;
        return null;
    }

    private Section findSectionByName(String name) {
        for (Section section : sections) if (section.name.equalsIgnoreCase(name)) return section;
        return null;
    }

    private String clean(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int getStatusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private int getNavigationBarHeight() {
        int id = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    @Override
    public void onBackPressed() {
        if (currentSectionId != null) renderHome();
        else super.onBackPressed();
    }

    private static class Section {
        final String id;
        String name;
        final ArrayList<Task> tasks = new ArrayList<>();
        Section(String id, String name) { this.id = id; this.name = name; }
    }

    private static class Task {
        final String id;
        String name;
        boolean done;
        Task(String id, String name, boolean done) {
            this.id = id; this.name = name; this.done = done;
        }
    }

    /** Draws and animates a strike-through without changing or hiding the task text. */
    private static class StrikeTextView extends TextView {
        private final Paint strikePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float strikeProgress = 0f;
        private ValueAnimator animator;

        StrikeTextView(Context context) {
            super(context);
            strikePaint.setColor(Color.WHITE);
            strikePaint.setStrokeCap(Paint.Cap.ROUND);
        }

        void setStrikeProgress(float value) {
            strikeProgress = Math.max(0f, Math.min(1f, value));
            invalidate();
        }

        void animateStrike(boolean checked) {
            if (animator != null) animator.cancel();
            float target = checked ? 1f : 0f;
            animator = ValueAnimator.ofFloat(strikeProgress, target);
            animator.setDuration(220);
            animator.setInterpolator(new DecelerateInterpolator());
            animator.addUpdateListener(animation -> {
                strikeProgress = (float) animation.getAnimatedValue();
                invalidate();
            });
            animator.start();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (strikeProgress <= 0f) return;
            android.text.Layout layout = getLayout();
            if (layout == null) return;
            strikePaint.setStrokeWidth(Math.max(2f, getTextSize() / 13f));
            strikePaint.setAlpha(245);
            int firstBaseline = getBaseline();
            int layoutFirstBaseline = layout.getLineBaseline(0);
            for (int i = 0; i < layout.getLineCount(); i++) {
                float left = getCompoundPaddingLeft() + layout.getLineLeft(i);
                float right = getCompoundPaddingLeft() + layout.getLineRight(i);
                float y = firstBaseline - layoutFirstBaseline + layout.getLineBaseline(i) - getTextSize() * 0.34f;
                canvas.drawLine(left, y, left + (right - left) * strikeProgress, y, strikePaint);
            }
        }
    }
}
